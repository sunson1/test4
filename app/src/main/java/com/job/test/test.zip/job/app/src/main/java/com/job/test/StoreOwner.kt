package com.job.test

import androidx.lifecycle.ViewModelStoreOwner

object StoreOwner {
    var viewModelStoreOwner : ViewModelStoreOwner? = null
}