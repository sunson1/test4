package com.job.test

typealias OnValueChange = (value: String) -> Unit
typealias OnImeKeyAction = () -> Unit
