package com.job.test

enum class FocusedTextFieldKey {
    USER,
    PASSWORD,
    NONE
}